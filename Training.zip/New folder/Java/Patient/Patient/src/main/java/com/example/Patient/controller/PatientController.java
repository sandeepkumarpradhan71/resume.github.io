package com.example.Patient.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Patient.model.Patient;
import com.example.Patient.service.PatientService;



@RestController
@RequestMapping("/patients")
public class PatientController {
	@Autowired
	PatientService service;
	
	@PostMapping
	public ResponseEntity<?>add(@RequestBody Patient patient){
		patient=service.add(patient);
		return ResponseEntity.status(200).body(patient);
		
	}
	
	@GetMapping
	public ResponseEntity<?>getalllist(){
		List<Patient> list=service.getalllist();
		return ResponseEntity.status(200).body(list);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<?>delete(@PathVariable int id){
		boolean res=service.delete(id);
		if(res) {
			return ResponseEntity.status(201).body("Delete Successfull");
		}
		return ResponseEntity.status(404).body(" NOT deleted");
		
	}
}
