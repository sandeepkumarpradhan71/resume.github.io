package com.example.Patient.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Patient.model.Patient;
import com.example.Patient.repository.PatientRepo;

@Service
public class PatientService {
	@Autowired
	PatientRepo repo;
 
	public Patient add(Patient patient) {
		return repo.save(patient);
	}
 
	public List<Patient> getalllist() {
		return repo.findAll();
	}
 
	public boolean delete(int id) {
		Patient stu=repo.findById(id).orElse(null);
		if(stu==null)
			return false;
		repo.delete(stu);
		return true;
	}
}
